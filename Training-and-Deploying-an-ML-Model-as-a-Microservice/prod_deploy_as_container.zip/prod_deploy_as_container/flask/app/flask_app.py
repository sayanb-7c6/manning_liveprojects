import os
from app import app
from nltk import download

download('punkt')
download('stopwords')


import sys
import pickle
from flask import Flask, request
from string import punctuation
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

stopwords_eng = stopwords.words('english')	


def extract_features(words):
    return [w for w in words if w not in stopwords_eng and w not in punctuation]


def bag_of_words(words):
    bag = {}
    for w in words:
        bag[w] = bag.get(w, 0) + 1
    return bag


if not 'google.colab' in sys.modules:
    model_file = open('sa_classifier.pickle', 'rb')
    model = pickle.load(model_file)
    model_file.close()

def get_sentiment(review):
    words = word_tokenize(review)
    words = extract_features(words)
    words = bag_of_words(words)
    return model.classify(words)


@app.route("/")
def index():
    app_name = os.getenv("APP_NAME")
    if app_name:
        return f"Hello from {app_name} running in a Docker container behind Nginx!"
    return "Hello from Flask"

@app.route('/predict', methods = ['GET', 'POST'])
def predict():
    if request.method == 'GET':
        input = request.args.get('input')
    else:
        input = request.get_json(force=True)['input']
    if not input:
        return 'No input value found'
    return get_sentiment(input)  
    